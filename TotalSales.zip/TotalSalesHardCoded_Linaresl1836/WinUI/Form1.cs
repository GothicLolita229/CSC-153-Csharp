﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 1/30/2022
* CSC 153
* Lourdes Linares
* reads the numbers in the sales array and adds them together
*/

namespace WinUI
{
    public partial class TotalSalesHardCoded : Form
    {

        const int SIZE = 7;
        double[] numbers = new double[SIZE];

        double totalAmountInArray = 0.0;


        public TotalSalesHardCoded()
        {
            InitializeComponent();
        }

        private void TotalSalesHardCoded_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            try
            {
                // Create an array to hold items read from the file.
                

                // Counter variable to use in the loop
                int index = 0;

                // Declare a StreamReader variable.
                StreamReader inputFile;

                // Open the file and get a StreamReader object.
                inputFile = File.OpenText("Sales.txt");

                // Read the file's contents into the array.
                while (index < numbers.Length && !inputFile.EndOfStream)
                {
                    numbers[index] = double.Parse(inputFile.ReadLine());
                    index++;
                }

                // Close the file.
                inputFile.Close();

                // Display the array elements in the list box.
                foreach (double value in numbers)
                {
                    listBox1.Items.Add(value);
                }
            }

            catch (Exception ex)
            {
                // Display an error message.
                MessageBox.Show(ex.Message);
            }

            //for an array, use .Length... for a list, use .Count
            for (int loopCounter = 0; loopCounter < numbers.Length; loopCounter++)
            {
                totalAmountInArray += numbers[loopCounter];
            }

            //to display in the box, it has to be a string
            MessageBox.Show(totalAmountInArray.ToString());
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
