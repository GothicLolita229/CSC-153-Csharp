﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/*RANDOM NUMBER FILE WRITER
 * Create an application that writes a series of random 
 * numbers to a file. Each random number should be in 
 * the range of 1 through 100. The application should 
 * let the user specify how many random numbers the 
 * file will hold and should use a SaveFileDialog control
 * to let the user specify the file’s name and location.
 * */

/*
* 2/21/2022
* CSC 153
* Lourdes Linares
* Random Number File Writer
 */

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //object, it's public and can be referenced in other methods
            userCount.Text = "";
        }

        private void createFile_Click(object sender, EventArgs e)
        {

            SaveFileDialog saveFile = new SaveFileDialog();
            var sfd = saveFile.ShowDialog();
            string filePath = saveFile.FileName;

            //allows system to download file or writing file locally
            StreamWriter numOutput = File.AppendText(filePath);
            
            int count = 1;
            //int randNum = 0;

            try
            {
                count = int.Parse(userCount.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
            
            try
            {
                if (sfd == DialogResult.OK)
                {
                    //numOutput = File.CreateText(sfd.FileName);
                    Random rand = new Random();

                    for (int index = 0; index < count; index++)
                    {
                        int randNum = rand.Next(1, 101);

                        numOutput.WriteLine(randNum);
                    }

                    numOutput.Close();
                    MessageBox.Show("File saved in path: " + saveFile.FileName);
                }
                else 
                {
                    MessageBox.Show("Didn't work");
                }
            }
            catch (Exception ex)
            {
                numOutput.Close();
                MessageBox.Show(ex.Message);
            }

        }

        private void clear_Click(object sender, EventArgs e)
        {
            userCount.Text = "";
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
