﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CandELibrary;

namespace CandELibrary
{
    public class Customer : Person
    {
        private int _customerNumber;
        private bool _mailList;

        public Customer()
        {
        }

        public Customer(string name, int customerNumber, bool mailList, string address, string telephoneNumber):base(name, address, telephoneNumber)
        {
            _mailList = mailList;
            _customerNumber = customerNumber;
            
        }
        public int CustomerNumber { get; set; }
        public bool MailList { get; set; }

        public override string ToString()
        {
            return base.ToString() +
                "Mail List Status: " + MailList + "\r\n" +
                "Customer Number: " + CustomerNumber + "\r\n";
        }
    }
}
