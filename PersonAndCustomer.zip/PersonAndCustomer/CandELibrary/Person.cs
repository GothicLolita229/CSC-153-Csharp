﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CandELibrary
{
    public class Person
    {
        private string _name;
        private string _address;
        private string _telephoneNumber;

        public Person()
        { }

        public Person(string name, string address, string telephoneNumber)
        {
            _name = name;
            _address = address;
            _telephoneNumber = telephoneNumber;
        }
        public string Name { get; set; }
        public string Address { get; set; }
        public string TelephoneNumber { get; set; }

        public override string ToString()
        {
            return "Person Name: " + Name + "\r\n" +
                "Person Address: " + Address + "\r\n" +
                "Person Telephone Number: " + TelephoneNumber + "\r\n";
        }
    }

}
