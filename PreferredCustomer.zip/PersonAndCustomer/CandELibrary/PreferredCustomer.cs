﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CandELibrary;

namespace CandELibrary
{
    public class PreferredCustomer : Customer
    {
        private int _customerPurchases;
        private decimal _discountLevel;

        public PreferredCustomer()
        {
        }

        public PreferredCustomer(int customerPurchases, decimal discountLevel, string name, int customerNumber, bool mailList, string address, string telephoneNumber) :base(name, customerNumber, mailList, address, telephoneNumber)
        {
            DiscountLevel = SetDiscountLevel();
            _customerPurchases = customerPurchases;

        }
        public int CustomerPurchases { get; set; }
        public decimal DiscountLevel { get; set; }
        public decimal SetDiscountLevel()
        {
            int i = CustomerPurchases/500;
            switch (i)
            {
                case 0:
                    return 0;
                    break;
                case 1:
                    return 0.05m;
                    break;
                case 2:
                    return 0.06m;
                    break;
                case 3:
                    return 0.08m;
                    break;
                default:
                    return 0.1m;
                    break;

            }

        }

        public double GetDiscount()
        {
            return CustomerPurchases * (double)DiscountLevel;
        }

        public double NewPurchaseAmount()
        {
            return CustomerPurchases - GetDiscount();
        }

        public override string ToString()
        {
            return base.ToString() +
                "Mail List Status: " + MailList + "\r\n" +
                    "Customer Number: " + CustomerNumber + "\r\n" +
                    "Name: " + Name + "\r\n" +
                    "Address: " + Address + "\r\n" +
                    "Telephone Number: " + TelephoneNumber + "\r\n" +
                    "Purchases: " + CustomerPurchases + "\r\n" +
                    "Purchase Amount: " + NewPurchaseAmount() + "\r\n"
                    ;
        }
    }
}
