﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CandELibrary;

/**
* 5.8.2022
* CSC 153
* Lourdes Linares
* Added Preferred Customer Class/Person and Customer Class using Inheritance
*/

namespace WinUI
{

    public partial class Form1 : Form
    {
        
        Customer customer = new Customer();
        PreferredCustomer Vip = new PreferredCustomer();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            customer.Name = textBox1.Text;
            customer.CustomerNumber = Convert.ToInt32(textBox5.Text);
            customer.Address = textBox2.Text;
            customer.TelephoneNumber = textBox3.Text;
            Vip.CustomerPurchases = Convert.ToInt32(textBox6.Text);

            textBox4.Text = Display();
            
        }

        private string Display()
        {
            return "Mail List Status: " + customer.MailList + "\r\n" +
                    "Customer Number: " + customer.CustomerNumber + "\r\n" +
                    "Name: " + customer.Name + "\r\n" +
                    "Address: " + customer.Address + "\r\n" +
                    "Telephone Number: " + customer.TelephoneNumber + "\r\n" +
                    "Purchases: " + Vip.CustomerPurchases + "\r\n" +
                    "Purchase Amount: " + Vip.NewPurchaseAmount() + "\r\n";
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
               customer.MailList = true;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                customer.MailList = false;
            }
        }
    }
}
