﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.petNameLabel = new System.Windows.Forms.Label();
            this.petTypeLabel = new System.Windows.Forms.Label();
            this.petAgeLabel = new System.Windows.Forms.Label();
            this.Enterbtn = new System.Windows.Forms.Button();
            this.Displaybtn = new System.Windows.Forms.Button();
            this.listBox = new System.Windows.Forms.ListBox();
            this.petNameBox = new System.Windows.Forms.TextBox();
            this.petAgeBox = new System.Windows.Forms.TextBox();
            this.petTypeBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // petNameLabel
            // 
            this.petNameLabel.AutoSize = true;
            this.petNameLabel.Location = new System.Drawing.Point(53, 39);
            this.petNameLabel.Name = "petNameLabel";
            this.petNameLabel.Size = new System.Drawing.Size(84, 17);
            this.petNameLabel.TabIndex = 0;
            this.petNameLabel.Text = "Pet\'s Name:";
            // 
            // petTypeLabel
            // 
            this.petTypeLabel.AutoSize = true;
            this.petTypeLabel.Location = new System.Drawing.Point(58, 123);
            this.petTypeLabel.Name = "petTypeLabel";
            this.petTypeLabel.Size = new System.Drawing.Size(79, 17);
            this.petTypeLabel.TabIndex = 1;
            this.petTypeLabel.Text = "Pet\'s Type:";
            // 
            // petAgeLabel
            // 
            this.petAgeLabel.AutoSize = true;
            this.petAgeLabel.Location = new System.Drawing.Point(65, 208);
            this.petAgeLabel.Name = "petAgeLabel";
            this.petAgeLabel.Size = new System.Drawing.Size(72, 17);
            this.petAgeLabel.TabIndex = 2;
            this.petAgeLabel.Text = "Pet\'s Age:";
            // 
            // Enterbtn
            // 
            this.Enterbtn.Location = new System.Drawing.Point(61, 288);
            this.Enterbtn.Name = "Enterbtn";
            this.Enterbtn.Size = new System.Drawing.Size(82, 50);
            this.Enterbtn.TabIndex = 3;
            this.Enterbtn.Text = "Enter Data";
            this.Enterbtn.UseVisualStyleBackColor = true;
            this.Enterbtn.Click += new System.EventHandler(this.Enterbtn_Click);
            // 
            // Displaybtn
            // 
            this.Displaybtn.Location = new System.Drawing.Point(274, 288);
            this.Displaybtn.Name = "Displaybtn";
            this.Displaybtn.Size = new System.Drawing.Size(81, 50);
            this.Displaybtn.TabIndex = 4;
            this.Displaybtn.Text = "Display Data";
            this.Displaybtn.UseVisualStyleBackColor = true;
            this.Displaybtn.Click += new System.EventHandler(this.Displaybtn_Click);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 16;
            this.listBox.Location = new System.Drawing.Point(452, 39);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(251, 260);
            this.listBox.TabIndex = 5;
            // 
            // petNameBox
            // 
            this.petNameBox.Location = new System.Drawing.Point(248, 39);
            this.petNameBox.Name = "petNameBox";
            this.petNameBox.Size = new System.Drawing.Size(123, 22);
            this.petNameBox.TabIndex = 6;
            // 
            // petAgeBox
            // 
            this.petAgeBox.Location = new System.Drawing.Point(248, 218);
            this.petAgeBox.Name = "petAgeBox";
            this.petAgeBox.Size = new System.Drawing.Size(123, 22);
            this.petAgeBox.TabIndex = 7;
            // 
            // petTypeBox
            // 
            this.petTypeBox.Location = new System.Drawing.Point(248, 123);
            this.petTypeBox.Name = "petTypeBox";
            this.petTypeBox.Size = new System.Drawing.Size(123, 22);
            this.petTypeBox.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.petTypeBox);
            this.Controls.Add(this.petAgeBox);
            this.Controls.Add(this.petNameBox);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.Displaybtn);
            this.Controls.Add(this.Enterbtn);
            this.Controls.Add(this.petAgeLabel);
            this.Controls.Add(this.petTypeLabel);
            this.Controls.Add(this.petNameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label petNameLabel;
        private System.Windows.Forms.Label petTypeLabel;
        private System.Windows.Forms.Label petAgeLabel;
        private System.Windows.Forms.Button Enterbtn;
        private System.Windows.Forms.Button Displaybtn;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.TextBox petNameBox;
        private System.Windows.Forms.TextBox petAgeBox;
        private System.Windows.Forms.TextBox petTypeBox;
    }
}

