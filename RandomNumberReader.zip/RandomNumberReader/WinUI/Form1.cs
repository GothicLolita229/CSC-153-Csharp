﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * RANDOM NUMBER FILE READER
 * This exercise assumes you have completed Programming Problem 13, 
 * Random Number File Writer. Create another application that uses 
 * an OpenFileDialog control to let the user select the file that
 * was created by the application that you wrote for Problem 13. 
 * This application should read the numbers from the file, display 
 * the numbers in a ListBox control, and then display the following data:
 * 
 * The total of the numbers
 * 
 * The number of random numbers read from the file
 */

/*
* 2/26/2022
* CSC 153
* Lourdes Linares
* Random Number File Reader
 */

namespace WinUI
{
    public partial class Form1 : Form
    {

        
        String randomNums;
        public Form1()
        {
            InitializeComponent();
        }
       
        private void inputFileButton_Click(object sender, EventArgs e)
        {
            var ofd = openFileDialog.ShowDialog();
            StreamReader inputFile;
            inputFile = File.OpenText(openFileDialog.FileName);
            

            try
            {
                if (ofd == DialogResult.OK)
                {
                    MessageBox.Show("Opening the Random Number file...");
                    int randomSum = 0;
                    int count = 0;

                    while (!inputFile.EndOfStream)
                    {
                        //gets all numbers and displays them
                        randomNums = inputFile.ReadLine();
                        listBox1.Items.Add(randomNums);

                        // adds numbers together
                        randomSum += int.Parse(randomNums);
                        count += 1;
                    }
                    //displays sum
                    listBox2.Items.Add(randomSum);

                    //displays count
                    MessageBox.Show(count.ToString());
                    
                }
                else
                {
                    MessageBox.Show("Canceled");
                }

                //TODO: Find out where to put this where it's going to work
                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }

            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            listBox1.Text = "";
            listBox2.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
