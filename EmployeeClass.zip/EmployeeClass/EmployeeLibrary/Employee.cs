﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        public Employee(string name, string dept, string position, int id)
        {
            Name = name;
            Department = dept;
            Position = position;
            IdNum = id;
        }
        public string Name { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }
        public int IdNum { get; set; }

        public override string ToString()
        {
            return base.ToString() + "Employee Info" + "\r\n" +
                "Name: " + Name + "\r\n" +
                "Department: " + Department + "\r\n" +
                "Position: " + Position + "\r\n" + 
                "ID Number: " + IdNum + "\r\n";
        }
    }
}
