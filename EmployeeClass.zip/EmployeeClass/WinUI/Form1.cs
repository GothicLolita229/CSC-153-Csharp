﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

/**
* 4.10.2022
* CSC 153
* Lourdes Linares
* Displays input about employee using class library and 
* constructors with info from text boxes.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        //Employee employee = new Employee(name, dept, position, id);
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int id = 0;
            if (int.TryParse(idNumTxt.Text, out id))
            {
                string name = nameTxt.Text;
                string position = posTxt.Text;
                string department = deptTxt.Text;
                Employee employee = new Employee(name, department, position, id);
                DisplayBox.Text = employee.ToString();
            }
            else 
            {
                DisplayBox.Text = "There was an error with" +
                    " your input. Please try again.";
            }
        }
    }
}
