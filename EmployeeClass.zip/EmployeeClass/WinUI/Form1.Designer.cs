﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.idNumTxt = new System.Windows.Forms.TextBox();
            this.deptTxt = new System.Windows.Forms.TextBox();
            this.posTxt = new System.Windows.Forms.TextBox();
            this.DisplayBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(108, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Department:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(95, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Position:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(258, 277);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 39);
            this.button1.TabIndex = 4;
            this.button1.Text = "Display Info";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(258, 34);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(83, 22);
            this.nameTxt.TabIndex = 5;
            // 
            // idNumTxt
            // 
            this.idNumTxt.Location = new System.Drawing.Point(258, 87);
            this.idNumTxt.Name = "idNumTxt";
            this.idNumTxt.Size = new System.Drawing.Size(83, 22);
            this.idNumTxt.TabIndex = 6;
            // 
            // deptTxt
            // 
            this.deptTxt.Location = new System.Drawing.Point(258, 142);
            this.deptTxt.Name = "deptTxt";
            this.deptTxt.Size = new System.Drawing.Size(83, 22);
            this.deptTxt.TabIndex = 7;
            // 
            // posTxt
            // 
            this.posTxt.Location = new System.Drawing.Point(258, 199);
            this.posTxt.Name = "posTxt";
            this.posTxt.Size = new System.Drawing.Size(83, 22);
            this.posTxt.TabIndex = 8;
            // 
            // DisplayBox
            // 
            this.DisplayBox.Location = new System.Drawing.Point(429, 44);
            this.DisplayBox.Multiline = true;
            this.DisplayBox.Name = "DisplayBox";
            this.DisplayBox.Size = new System.Drawing.Size(206, 232);
            this.DisplayBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 450);
            this.Controls.Add(this.DisplayBox);
            this.Controls.Add(this.posTxt);
            this.Controls.Add(this.deptTxt);
            this.Controls.Add(this.idNumTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.TextBox idNumTxt;
        private System.Windows.Forms.TextBox deptTxt;
        private System.Windows.Forms.TextBox posTxt;
        private System.Windows.Forms.TextBox DisplayBox;
    }
}

