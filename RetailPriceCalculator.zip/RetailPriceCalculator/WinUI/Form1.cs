﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceCalculatorLibrary;

/* RETAIL PRICE CALCULATOR
 * Create an application that lets the user enter an item’s wholesale cost and its markup percentage. 
 * It should then display the item’s retail price. For example:
 * If an item’s wholesale cost is $5.00 and its markup percentage is 100 percent, then the item’s retail price is $10.00.
 * If an item’s wholesale cost is $5.00 and its markup percentage is 50 percent, then the item’s retail price is $7.50.
 * The program should have a method named CalculateRetail that receives the wholesale cost and the markup percentage as
 * arguments and returns the retail price of the item. 
*/

/**
* 03/03/2022
* CSC 153
* Lourdes Linares
* Calculates retail price from wholesale and markup
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Calculator maths = new Calculator(); // if method in class is not static you need to declare a new instance of object
            decimal wholesalePrice = 0;
            decimal markupPercentage = 0;

            try
            {
                decimal.TryParse(wholesaleTextBox.Text, out wholesalePrice);
                decimal.TryParse(markupTextBox.Text, out markupPercentage);
                //decimal retailPrice = maths.CalculateRetail(ref wholesalePrice, markupPercentage);
                decimal retailPrice = Calculator.CalculateRetail(ref wholesalePrice, markupPercentage);
                displayTotal.Text = retailPrice.ToString("c");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
