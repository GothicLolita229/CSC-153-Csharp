﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 2/5/2022
* CSC 153
* Lourdes Linares
* Compares two arrays of test answers and lists grade data
*/

/*After the student’s answers have been read from the file, the program should display a message indicating whether the student passed 
or failed the exam. (A student must correctly answer 15 of the 20 questions to pass the exam.) It should then display the total number 
of correctly answered questions, the total number of incorrectly answered questions, and a list showing the question numbers of the 
incorrectly answered questions.*/

namespace WinUI
{
    public partial class Form1 : Form
    {


    public Form1()
        {
            InitializeComponent();
           
        }

        private void checkAnswers_Click(object sender, EventArgs e)
        {
            const int SIZE = 20;
            string[] studentGrade = new string[SIZE];
            string[] correctAnswers = new string[] { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
            int[] wrongAnswers = new int[SIZE];

            try
            {

                // Create an array to hold items read from the file.


                // Counter variable to use in the loop
                int counter = 0;

                // Declare a StreamReader variable.
                StreamReader inputFile;

                // Open the file and get a StreamReader object.
                inputFile = File.OpenText("studentAnswers.txt");

                // Read the file's contents into the array.
                while (counter < studentGrade.Length && !inputFile.EndOfStream)
                {
                    studentGrade[counter] = (inputFile.ReadLine());
                    counter++;
                }

                // Close the file.
                inputFile.Close();

                // COMMENT: Display the array elements in the list box.
                
            }

            catch (Exception ex)
            {
                // Display an error message.
                MessageBox.Show("Could not find your test answers.");
            }

            int comparisonCounter = 0;
            int questionsCorrect = 0;
            
           

            // Next determine whether the elements contain the same data.
            while (comparisonCounter < SIZE)
            {
                if (correctAnswers[comparisonCounter] != studentGrade[comparisonCounter])
                {
                    
                    wrongAnswers[comparisonCounter] = comparisonCounter + 1;
                    //add incorrect items to array wrongAnswers
                    
                }
                else 
                {
                    
                    questionsCorrect++;

                }
                comparisonCounter++;
            }
            if (questionsCorrect >= 15)
            {
                outputListBox.Items.Add("You passed!!!!!");
            }
            else
            {
                outputListBox.Items.Add("You fail! Good day, SIR!!");
            }

            outputListBox.Items.Add("Questions Correct: " + questionsCorrect);
            outputListBox.Items.Add("Questions Incorrect: " + (SIZE - questionsCorrect));
            
            //for each one check "is it empty" if it's not empty 
            foreach (int value in wrongAnswers) 
            {
                if (value != 0)
                {
                    outputListBox.Items.Add(value);
                }
            }



        }
    }
}
