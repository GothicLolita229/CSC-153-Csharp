﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallingDistanceClassLibrary
{
    public class CalculatorClass
    {
        public static double Calculator(double t)
        {
            const double g = 9.8;
            double d;

            d = 0.5 * g * Math.Pow(t, 2);

            return d;
        }
    }
}
