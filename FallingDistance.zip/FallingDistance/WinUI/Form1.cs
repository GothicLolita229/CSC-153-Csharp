﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FallingDistanceClassLibrary;

/*FALLING DISTANCE
 * When an object is falling because of gravity, the following formula can be used to determine the distance 
 * the object falls in a specific time period:
 * 
 * d = 1/2 gt^2
 * 
 * The variables in the formula are as follows: 
 * d is the distance in meters,
 * g is 9.8, 
 * and t is the amount of time in seconds that the object has been falling. 
 * 
 * Create an application that allows the user to enter the amount
 * of time that an object has fallen and then displays the distance that the object fell. The application should 
 * have a method named FallingDistance. The FallingDistance method should accept an object’s falling time 
 * (in seconds) as an argument.The method should return the distance in meters that the object has fallen 
 * during that time interval.
 */

/**
* 03/12/2022
* CSC 153
* Lourdes Linares
* Calculates distance fallen in meters based off fall time in seconds
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double t;
            try
            {
                double.TryParse(secsTxtBox.Text, out t);
                double d = CalculatorClass.Calculator(t);
                distTxtBox.Text = d.ToString("n") + " meters";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }
    }
}
